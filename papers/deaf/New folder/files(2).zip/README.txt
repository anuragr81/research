SUBMISSION BUNDLE
=================
Paper:   Loss Aversion, Endogenous Reference Points, and
         Boom-Bust Asymmetry in Financial Wealth Dynamics
Author:  Anurag Rathi (ORCID: 0000-0002-6477-4430)
Journal: Decisions in Economics and Finance (Springer)
Portal:  https://www.editorialmanager.com/deaf/
Date:    May 2026

FILES
-----
manuscript.tex        Main manuscript — upload as main document
bibliography.bib      BibTeX bibliography — upload as source file
title_page.tex        Title page with author details and declarations
cover_letter.tex      Cover letter addressed to Prof. Salvatore Greco
summary_300.txt       300-word summary (~390 words with full substance)
executive_summary.txt 1,500-word executive summary
README.txt            This file — for local reference only

COMPILATION
-----------
  pdflatex manuscript
  bibtex   manuscript
  pdflatex manuscript
  pdflatex manuscript

Or: latexmk -pdf manuscript

NOTE: First pdflatex pass will show citation warnings — these are
normal and resolve after the bibtex step. Two further pdflatex
passes are needed to resolve all cross-references.

PORTAL SUBMISSION CHECKLIST
----------------------------
[ ] Compile manuscript.tex to PDF — verify all tables, equations,
    cross-references, and bibliography render correctly
[ ] Confirm abstract is 249 words (within DEF 150-250 limit)
[ ] Confirm 6 keywords present below abstract
[ ] Log in to https://www.editorialmanager.com/deaf/
[ ] Select article type: Original Paper
[ ] Upload files:
      - title_page.tex  (title page)
      - manuscript.tex  (main manuscript)
      - bibliography.bib (source file)
      - manuscript.pdf  (compiled PDF)
[ ] Paste abstract into portal abstract field
[ ] Enter 6 keywords in portal keyword field
[ ] Upload cover_letter.tex (or compiled PDF) in cover letter field
[ ] Complete competing interests declaration on portal form
[ ] Submit

PENDING SMALL ITEMS (post-submission)
--------------------------------------
- wang2017 citation: add to cross-sectional prediction paragraph
- delong1990 citation: add to noise trader justification
- Beta vs g figure: add or remove reference in calibration section
- Jeffrey paper: start in separate session
