#!/usr/bin/env python3
r"""
Machine-checkable verification of Proposition (Structural trap) / `prop:coincidence`.

Manuscript statement:
    Under Assumption (Group sufficiency) the marker likelihood is independent of
    class within a group, P(m | c, g) = P(m | g). Then for any prior the Bayesian
    posterior on class equals the prior, P(c | m, g) = P(c | g). A Bayesian observer
    therefore leaves the within-group conditional unrevised after observing the marker,
    which is exactly the Jeffrey invariance condition. The two updating rules carry the
    identical conditional in every period, drive the identical discrimination rate
    phi = s_g F(cbar_g), and induce the identical law of motion; the closure trap of
    `prop:class-closure` obtains under both.

This script checks each step symbolically with SymPy. Every claim is an `assert`,
so the script exits non-zero if any step fails. Run:  python3 proof_coincidence_sympy.py
"""
import sympy as sp

PASS = []
def check(name, expr_is_zero):
    """Assert that `expr_is_zero` simplifies to 0 (an identity) and record it."""
    z = sp.simplify(expr_is_zero)
    assert z == 0, f"FAILED: {name}  (residual = {z})"
    PASS.append(name)
    print(f"  [ok] {name}")

print("=" * 70)
print("STEP 1  Bayes-invariance lemma (the one substantive claim)")
print("=" * 70)
# Discrete class space. The number of classes is arbitrary: we fold the prior's
# total mass into a single symbol S = sum_j p_j, so the argument is general in n.
#   p_i  : prior P(c_i | g)         (an arbitrary class i)
#   k    : the common likelihood value under sufficiency, P(m | c_j, g) = k for all j
#   S    : sum_j p_j  (= 1 for a normalised prior)
p_i, k, S = sp.symbols('p_i k S', positive=True)

# Sufficiency makes the likelihood constant in class, so the marginal (normaliser) is
#   Z = sum_j P(m | c_j, g) p_j = sum_j k p_j = k * S.
Z = k * S

# Posterior by Bayes' rule:  P(c_i | m, g) = P(m | c_i, g) p_i / Z = k p_i / (k S).
posterior = (k * p_i) / Z
print(f"  posterior  P(c_i|m,g) = k*p_i / (k*S)  simplifies to  {sp.simplify(posterior)}")

# For any prior (normalised or not) the k cancels: posterior = p_i / S.
check("posterior reduces to p_i / S (the k cancels)", posterior - p_i / S)

# For a normalised prior, S = 1, so the posterior equals the prior exactly.
posterior_norm = posterior.subs(S, 1)
check("normalised prior (S=1): posterior P(c_i|m,g) = prior p_i", posterior_norm - p_i)

print()
print("=" * 70)
print("STEP 2  Necessity: the assumption is load-bearing")
print("=" * 70)
# Drop sufficiency: a two-class example with class-dependent likelihood L0 != L1.
# Then the posterior does NOT equal the prior in general -- so the invariance is a
# genuine consequence of Assumption (Group sufficiency), not an algebraic triviality.
p0, p1, L0, L1 = sp.symbols('p0 p1 L0 L1', positive=True)
Z2 = L0 * p0 + L1 * p1
posterior0 = (L0 * p0) / Z2                      # normalised prior: p0 + p1 = 1
gap = sp.simplify((posterior0 - p0).subs(p1, 1 - p0))
print(f"  with L0 != L1:  posterior_0 - p0 = {gap}")
# Factor shows the gap vanishes iff L0 = L1 (i.e. exactly sufficiency):
gap_factored = sp.factor(gap)
print(f"  factored:        {gap_factored}")
assert gap != 0, "FAILED: posterior should differ from prior when likelihood varies"
# And it collapses to 0 precisely when L0 = L1:
check("gap = 0 exactly when L0 = L1 (sufficiency restored)", gap.subs(L1, L0))
PASS.append("posterior != prior when likelihood is class-dependent")
print("  [ok] posterior != prior when likelihood is class-dependent")

print()
print("=" * 70)
print("STEP 3  Identical conditional  ==>  identical map  ==>  identical dynamics")
print("=" * 70)
# The law of motion (eq:dynamic), as a function of the discrimination rate phi:
cbar, delta, mu, gam = sp.symbols('cbar delta mu gamma_t', positive=True)
s_g = sp.symbols('s_g', positive=True)
F = sp.Function('F')

def H(phi):
    """Intergenerational map: exclusion + convergence + mobility."""
    return cbar * (1 - delta * phi) + mu * (1 - cbar) + gam * cbar * (1 - cbar)

# Both rules feed phi = s_g * F(conditional). By STEP 1 the conditional each rule
# carries is identical (the prior cbar_g), so the phi each feeds in is the same object.
phi_jeffrey = s_g * F(cbar)   # Jeffrey: conditional held fixed, evaluated at cbar_g
phi_bayes   = s_g * F(cbar)   # Bayes under sufficiency: posterior = prior = cbar_g
check("phi_Bayes = phi_Jeffrey under sufficiency", phi_bayes - phi_jeffrey)
check("map H is identical under the two rules", H(phi_bayes) - H(phi_jeffrey))
# Identical maps have identical fixed points (residuals coincide as functions):
check("fixed-point residual Psi = H(c)-c coincides for both rules",
      (H(phi_bayes) - cbar) - (H(phi_jeffrey) - cbar))

print()
print("=" * 70)
print("STEP 4  The common map carries the closure trap (reproduces prop:class-closure)")
print("=" * 70)
# Not part of the coincidence claim itself -- the manuscript defers trap existence to
# prop:class-closure -- but we confirm the *common* map is the bistable one, so "the
# trap obtains under both" is substantiated. Canonical F(c) = (1-c)^2, base parameters.
c = sp.symbols('c', real=True)
Fc = (1 - c) ** 2
base = {delta: sp.Rational(1, 2), mu: sp.Rational(1, 20), s_g: 1, gam: sp.Rational(1, 10)}
phi_c = base[s_g] * Fc
Psi = (c * (1 - base[delta] * phi_c) + base[mu] * (1 - c)
       + base[gam] * c * (1 - c) - c)
roots = sp.solve(sp.Eq(Psi, 0), c)
real_roots = sorted([sp.nsimplify(r) for r in roots if r.is_real])
in_unit = [r for r in real_roots if 0 <= float(r) <= 1 + 1e-9]
print(f"  Psi(c) = 0 real roots in [0,1]: {[float(r) for r in in_unit]}")
# A trap means multiple fixed points in the unit interval (low trap + integration,
# generically with an interior tipping point between them).
assert len(in_unit) >= 2, f"FAILED: expected multiple fixed points (trap), got {in_unit}"
PASS.append(f"common map is bistable: {len(in_unit)} fixed points in [0,1]")
print(f"  [ok] common map is bistable ({len(in_unit)} fixed points in [0,1]) -> trap exists")

print()
print("=" * 70)
print(f"ALL {len(PASS)} CHECKS PASSED")
print("=" * 70)
for i, name in enumerate(PASS, 1):
    print(f"  {i:2d}. {name}")
print()
print("Conclusion: under Assumption (Group sufficiency) the Bayesian posterior equals")
print("the prior (Step 1, and necessarily so -- Step 2); the two updating rules therefore")
print("induce the identical map (Step 3), whose fixed-point structure is the closure trap")
print("(Step 4). The trap is a property of the information structure, not the updating rule.")
