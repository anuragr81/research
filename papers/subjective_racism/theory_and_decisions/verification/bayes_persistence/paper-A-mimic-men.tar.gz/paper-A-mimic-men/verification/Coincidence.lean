/-
  Structural trap (Proposition `prop:coincidence`) -- Lean 4 + Mathlib.

  This formalises the ONE substantive step of the proof: under Group sufficiency
  the marker likelihood is independent of class, and then the Bayesian posterior
  on class equals the prior. That equality IS the Jeffrey invariance condition,
  so the two updating rules carry the identical conditional, drive the identical
  discrimination rate, and induce the identical law of motion.

  Caveat: this file was written for Lean 4 / a recent Mathlib but was NOT compiled
  in the environment that produced it. The mathematics is elementary and the proof
  is short; if a Mathlib lemma name has drifted in your toolchain version
  (`Finset.mul_sum`, `div_self`, ...), the fixes are mechanical. The companion
  SymPy script `proof_coincidence_sympy.py` checks the same statements
  computationally and does run.
-/
import Mathlib

open Finset

namespace StructuralTrap

variable {C : Type*} [Fintype C]

/-- **Bayes-invariance under Group sufficiency.**
`p` is the prior `P(c | g)` (a probability distribution, `∑ p = 1`) and `L` is the
marker likelihood `P(m | c, g)`. Group sufficiency says `L` is constant in the class,
`hL : ∀ c, L c = k`, with the marker actually observable, `hk : k ≠ 0`. Then the
Bayesian posterior, `L c * p c / (∑ c', L c' * p c')`, equals the prior `p c` at every
class. Observing the marker leaves the within-group conditional unchanged -- exactly
the Jeffrey invariance condition. -/
theorem bayes_invariance
    (p L : C → ℝ) (k : ℝ)
    (hL : ∀ c, L c = k) (hk : k ≠ 0) (hp : ∑ c, p c = 1) :
    ∀ c, L c * p c / (∑ c', L c' * p c') = p c := by
  intro c
  -- Sufficiency makes the normaliser collapse: ∑ c', L c' p c' = k ∑ c', p c' = k·1 = k.
  have hZ : (∑ c', L c' * p c') = k := by
    calc (∑ c', L c' * p c')
        = ∑ c', k * p c' := by
            apply Finset.sum_congr rfl
            intro c' _
            rw [hL c']
      _ = k * ∑ c', p c' := by rw [← Finset.mul_sum]
      _ = k := by rw [hp, mul_one]
  -- Substitute, then the common factor k cancels.
  rw [hL c, hZ, mul_comm k (p c), mul_div_assoc, div_self hk, mul_one]

/-- **Necessity.** Drop sufficiency and the conclusion fails. Two classes, uniform
prior `(1/2, 1/2)`, and a class-dependent likelihood `(1, 0)`: the posterior at
class `0` is `1`, not `1/2`. So the invariance is a genuine consequence of Group
sufficiency, not an algebraic triviality. -/
example :
    ∃ (p L : Fin 2 → ℝ) (c : Fin 2),
      (∑ c, p c = 1) ∧ L c * p c / (∑ c', L c' * p c') ≠ p c := by
  refine ⟨![1 / 2, 1 / 2], ![1, 0], 0, ?_, ?_⟩
  · simp [Fin.sum_univ_two]; norm_num
  · simp [Fin.sum_univ_two]; norm_num

/-- **Bookkeeping step: equal conditionals give equal dynamics.**
Once the conditional driving discrimination coincides under the two rules -- which is
the content of `bayes_invariance`, the Bayesian posterior `cbarB` equalling the
unrevised prior `cbarJ` -- the induced one-step map agrees for any discrimination-rate
function `F`, salience `s`, and law of motion `H`. Hence the two rules share their
fixed-point set. Existence of the closure trap for that common map is
Proposition `prop:class-closure` (a cubic root count), proved analytically in the
paper and not re-derived here. -/
theorem map_coincides
    (F : ℝ → ℝ) (s : ℝ) (H : ℝ → ℝ) (cbarJ cbarB : ℝ)
    (hcond : cbarB = cbarJ) :
    H (s * F cbarB) = H (s * F cbarJ) := by
  rw [hcond]

end StructuralTrap
