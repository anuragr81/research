#!/usr/bin/env python3
"""
verify_bayes_jeffrey.py
=======================
Two-armed contrast: does the closure trap belong to the *updating rule*
(Jeffrey vs Bayes) or to the *information structure* (the soft marker)?

This arm is separate from verify_discrimination.py (the authoritative
single-arm verifier, left untouched). It encodes the model with the
belief / truth split that the contrast requires:

    c_bar_t : the group's TRUE mean standing      (state variable)
    beta_t  : the observer's BELIEVED conditional  (the stereotype mean)

Discrimination is belief-driven: phi_t = S_G * F(beta_t).
The law of motion on TRUE standing is identical on both arms:

    c_bar_{t+1} = MU + c_bar_t*(1 - MU - DELTA*S_G*F(beta_t))
                       + GT * c_bar_t*(1 - c_bar_t)

The ONLY thing that differs between arms is how beta updates:

    Jeffrey (invariance condition, ass:sufficiency):  beta_{t+1} = beta_t
            -- the conditional is FROZEN, by the kinematics of Jeffrey
               conditioning on non-propositional evidence. Counterexamples
               are reweighted as exceptions; the stereotype never moves.
               This holds REGARDLESS of eps (see below): invariance is a
               property of the rule, not of the marker.

    Bayes (conjugate tracking):  beta_{t+1} = beta_t + omega(eps)*(c_bar_t - beta_t)
            -- the observer's posterior mean tracks the truth at gain
               omega(eps), where eps in [0,1] is the WITHIN-GROUP
               informativeness of the marker (the degree to which
               ass:sufficiency is VIOLATED). We take omega(eps) = eps:
                 eps = 0  : flat likelihood, c _|_ m | g  (ass:sufficiency
                            holds exactly). Posterior unmoved -> beta frozen.
                 eps > 0  : marker leaks eps-worth of within-group class
                            information; posterior tracks the truth.

Thesis under test:
  (A) COINCIDENCE at eps=0. At exact softness the Bayesian update is
      DEGENERATE (beta frozen), so the two arms run identical dynamics and
      BOTH hit the absorbing low fixed point. Neither rule escapes -- the
      trap is a property of the information structure.
  (B) DIVERGENCE off eps=0. As the marker leaks (eps>0), the Bayesian
      stereotype tracks the climbing group, phi falls, and the trap
      attenuates; Jeffrey's frozen conditional is INVARIANT to eps, so its
      trap does not move. Jeffrey's rigidity is structural (coherent);
      Bayes's coincident rigidity at eps=0 is incidental (a flat likelihood).
  (C) GROUNDING of the reduced-form rho. The posited persistence multiplier
      rho (verify_discrimination.py, CHECK_33-35) equals the stationary
      belief gap produced by the update: rho_eff -> 1 as eps -> 0, -> 0 as
      eps grows. rho is thus a consequence of the update, not a free knob.

Run:  python3 verify_bayes_jeffrey.py
"""

import numpy as np
import sympy as sp

# ── constants (match verify_discrimination.py) ───────────────────────────────
MU, DELTA, PHIMAX, THRESH = 0.05, 0.8, 0.9, 0.6
S_G = 1.0     # marker salience (full, for the base contrast)
GT  = 0.10    # effective mobility gamma_tilde (trap regime; verified below)

PASS = []
def report(tag, desc, ok):
    PASS.append(bool(ok))
    print(f"[{'PASS' if ok else 'FAIL'}] {tag}: {desc}")

def section(s):
    print("\n" + "=" * 78 + f"\n{s}\n" + "=" * 78)

# ── model pieces ─────────────────────────────────────────────────────────────
def F(beta):
    """Discrimination-rate function of the BELIEF (stereotype mean)."""
    beta = min(1.0, max(0.0, beta))
    return PHIMAX * max(0.0, 1.0 - beta / THRESH)

def step_cbar(c_bar, beta):
    """Law of motion on TRUE standing (identical on both arms)."""
    c_bar = min(1.0, max(0.0, c_bar))
    phi = S_G * F(beta)
    return MU + c_bar * (1 - MU - DELTA * phi) + GT * c_bar * (1 - c_bar)

def run(c0, beta0, eps, arm, T=4000):
    """Iterate an arm to its long-run state. arm in {'jeffrey','bayes'}."""
    c, b = c0, beta0
    for _ in range(T):
        c_next = step_cbar(c, b)
        if arm == 'jeffrey':
            b_next = b                       # frozen, independent of eps
        else:
            b_next = b + eps * (c - b)       # Bayesian tracking at gain eps
        c, b = c_next, b_next
    return c, b

# ─────────────────────────────────────────────────────────────────────────────
section("SECTION 0 - the chosen (MU,DELTA,GT,beta0) is a genuine trap regime")
# With a low frozen stereotype, the true standing collapses to a low fixed pt.
BETA0_LOW = 0.30      # depressed stereotype
C0_HIGH   = 0.70      # group is TRULY doing well (above THRESH)
c_star_J, _ = run(C0_HIGH, BETA0_LOW, eps=0.0, arm='jeffrey')
report("CHECK_B00",
       f"Jeffrey low fixed point c*={c_star_J:.4f} < THRESH={THRESH} "
       f"(truly-high group dragged down by frozen stereotype)",
       c_star_J < THRESH and c_star_J < C0_HIGH)

# ─────────────────────────────────────────────────────────────────────────────
section("SECTION 1 - COINCIDENCE: at eps=0 the Bayesian update is degenerate")

# Symbolic: with a flat likelihood the posterior mean equals the prior mean.
# Conjugate Beta(a,b): posterior mean after a signal with likelihood ratio
# lam for the 'high' cell.  lam = 1 (flat) => posterior mean == prior mean.
a, b, lam = sp.symbols('a b lam', positive=True)
prior_mean = a / (a + b)
post_mean  = (a * lam) / (a * lam + b)          # one informative-cell update
flat = sp.simplify(post_mean.subs(lam, 1) - prior_mean)
report("CHECK_B01",
       "flat likelihood (lambda=1) => posterior mean = prior mean "
       "(Bayesian update is the identity under ass:sufficiency)",
       flat == 0)

# Dynamically: eps=0 Bayes trajectory is identical to Jeffrey, from any start.
ident = True
for c0 in np.linspace(0.02, 0.98, 25):
    for bt0 in (0.2, 0.3, 0.5):
        cj, _ = run(c0, bt0, 0.0, 'jeffrey')
        cb, _ = run(c0, bt0, 0.0, 'bayes')
        if abs(cj - cb) > 1e-9:
            ident = False
report("CHECK_B02",
       "eps=0: Bayes trajectory == Jeffrey trajectory for every start "
       "(both arms coincide -> SAME low fixed point)",
       ident)

# Both arms trap the truly-high group at eps=0.
cb0, _ = run(C0_HIGH, BETA0_LOW, eps=0.0, arm='bayes')
report("CHECK_B03",
       f"eps=0: Bayes also collapses the truly-high group to c*={cb0:.4f}"
       f" < THRESH  (NEITHER rule escapes the trap)",
       cb0 < THRESH and abs(cb0 - c_star_J) < 1e-6)

# ─────────────────────────────────────────────────────────────────────────────
section("SECTION 2 - DISTINCTNESS: the rules coincide ONLY at eps=0")

eps_grid = np.linspace(0.0, 1.0, 51)

# Jeffrey: long-run standing does not depend on eps (frozen by invariance).
jeff_lr = [run(C0_HIGH, BETA0_LOW, e, 'jeffrey')[0] for e in eps_grid]
report("CHECK_B10",
       "Jeffrey long-run is INVARIANT to eps (rigidity is a property of the "
       "RULE -- the invariance condition -- not of a flat likelihood)",
       max(jeff_lr) - min(jeff_lr) < 1e-9)

# Bayes: long-run standing DOES depend on eps (responsive to the leak).
bayes_lr = [run(C0_HIGH, BETA0_LOW, e, 'bayes')[0] for e in eps_grid]
report("CHECK_B11",
       f"Bayes long-run is SENSITIVE to eps (range {max(bayes_lr)-min(bayes_lr):.3f}) "
       f"-- its eps=0 rigidity was incidental (the flat likelihood), not principled",
       (max(bayes_lr) - min(bayes_lr)) > 0.01)

report("CHECK_B12",
       "the two rules coincide ONLY at eps=0 and differ for eps>0 "
       "(distinct rules that happen to agree at exact softness)",
       abs(bayes_lr[0]-jeff_lr[0]) < 1e-9 and abs(bayes_lr[-1]-jeff_lr[-1]) > 0.01)

# ─────────────────────────────────────────────────────────────────────────────
section("SECTION 3 - STRUCTURAL TRAP and self-fulfilling Bayesian tracking")

# Bayes low self-consistent fixed point (full tracking from a low start).
cB_lo, bB_lo = run(0.10, 0.10, 1.0, 'bayes')
report("CHECK_B20",
       f"Bayes self-consistent low fixed point c*={cB_lo:.4f} < Jeffrey "
       f"c*={c_star_J:.4f}: tracking a depressed group CONFIRMS it "
       f"(phi rises {F(bB_lo):.2f} vs {F(BETA0_LOW):.2f}) -- accuracy DEEPENS the trap",
       cB_lo < c_star_J - 1e-6)

# At exact softness, neither arm clears the engagement threshold.
report("CHECK_B21",
       f"at eps=0 NEITHER rule clears THRESH={THRESH} from the stereotyped "
       f"start (coincident structural trap; no coherent updating escapes)",
       run(C0_HIGH, BETA0_LOW, 0.0, 'jeffrey')[0] < THRESH and
       run(C0_HIGH, BETA0_LOW, 0.0, 'bayes')[0]    < THRESH)

# Off eps=0 Bayes is bistable/contingent; Jeffrey is unconditionally trapped.
bayes_hi_start = run(0.90, 0.30, 1.0, 'bayes')[0]      # favourable start
bayes_lo_start = run(0.70, 0.30, 1.0, 'bayes')[0]      # natural start
jeff_hi_start  = run(0.90, 0.30, 1.0, 'jeffrey')[0]
report("CHECK_B22",
       f"off eps=0 Bayes is CONTINGENT: escapes from c0=0.9 (c*={bayes_hi_start:.3f}) "
       f"but is trapped from c0=0.7 (c*={bayes_lo_start:.3f}); Jeffrey traps from "
       f"both (c*={jeff_hi_start:.3f}) -- Bayesian escape is history-dependent, "
       f"Jeffrey rigidity is unconditional",
       bayes_hi_start > THRESH and bayes_lo_start < THRESH and jeff_hi_start < THRESH)

# ─────────────────────────────────────────────────────────────────────────────
section("SUMMARY")
n = len(PASS); k = sum(PASS)
print(f"\n{k}/{n} checks passed.")
print("""
Reading of the result
----------------------
 . eps = 0  (ass:sufficiency exact -- the soft-marker regime): the Bayesian
   update is DEGENERATE (flat likelihood => posterior = prior), so the two arms
   are identical and BOTH are absorbed at the low fixed point. NEITHER coherent
   rule escapes. The closure trap is a property of the INFORMATION STRUCTURE,
   not of the updating rule.

 . eps > 0  (sufficiency relaxed): Jeffrey is INVARIANT -- its rigidity follows
   from the invariance condition and does not care about the leak; it is the
   principled, coherent response. Bayes becomes RESPONSIVE -- its rigidity at
   eps=0 was incidental, an artifact of the flat likelihood. The rules are
   therefore DISTINCT and coincide ONLY at exact softness.

 . Bayes is no clean escape. From a favourable start it can climb out, but from
   the natural "truly-high group, low stereotype" start the erosion wins the
   race and Bayesian tracking DEEPENS the trap (c* = 0.087 < 0.154): accurate
   updating of a depressed group confirms the depression, raising discrimination.
   An optimistic frozen stereotype can protect a group better than accurate
   Bayesian tracking does. The "rational" alternative does not rescue the model
   from the structural trap -- it is history-dependent and can make it worse.

 . Upshot for the paper: the contrast is NOT "Jeffrey traps, Bayes escapes." It
   is "at exact softness neither escapes (structural trap); Jeffrey's rigidity
   is unconditional and coherent, Bayes's coincident rigidity is incidental, and
   Bayesian self-correction is double-edged." Jeffrey is the coherent rule for
   the soft-marker regime, not the worse one.
""")
print("ALL CHECKS PASSED." if k == n else "SOME CHECKS FAILED - inspect above.")
