# Stereotype Rigidity in Social Inferences: A "Mimic Men" Dilemma

Manuscript bundle. Snapshot as of 2026-06-28. Now on the **Springer Nature
`sn-jnl` template** (author-year, `sn-basic` style) for submission to
Theory and Decision.

## Contents

- `manuscript.tex` — the paper, `\documentclass[pdflatex,sn-basic]{sn-jnl}`.
- `sn-jnl.cls` — Springer Nature class (required to compile).
- `sn-basic.bst` — Springer Nature Basic author-year bib style (required).
- `bibliography.bib` — references (43 entries; AignerCain1977, Fisher1930,
  Strogatz2015 re-added here so the bundle compiles — manage as you prefer).
- `figures/` — figure PDFs and generators.
  - `fig_composed_map.pdf` — composed map with shaded basins + cobweb
    (regenerated; produced by `regen_composed_map.py`).
  - `fig_bifurcation_delta.pdf`, `fig_trajectory_timeseries.pdf` — unchanged.
  - generators: `generate_figures.py`, `generate_more_figures.py`,
    `generate_proposed_figures.py`, `regen_composed_map.py`.
- `verification/` — paradigm-neutral verification artifacts (not compiled
  into the paper): `verify_discrimination.py`, `verify_tau_extension.py`,
  `verify_topology.lean`.
- `docs/` — working notes: `HANDOVER.md`, `TODO_CHANGES.md`, `COLON_AUDIT.md`.

## Compiling

`sn-jnl.cls` and `sn-basic.bst` must be on the path (they're in this folder).

```
pdflatex manuscript.tex
bibtex   manuscript
pdflatex manuscript.tex
pdflatex manuscript.tex
```

Produces a ~39-page PDF, no undefined references or citations.

## Open items before submission (see docs/TODO_CHANGES.md)

- Author/affiliation are placeholders (`[Author/Affiliation removed for
  review]`). T&D is single-blind — de-anonymise the title page: fill
  `\author[1]{\fnm{First}\sur{Last}}` and `\affil[1]{\orgname{...}}`.
- The abstract currently contains citations; Springer/T&D guidance
  discourages this — consider removing or rephrasing.
- Headings: keep to three levels (section/subsection/subsubsection); no
  fourth level (T&D + template rule).
- Colon reduction pass (COLON_AUDIT.md) is manual/ongoing.

## Regenerating the closure-map figure

```
python3 figures/regen_composed_map.py
```
Parameters (mu, delta, s_g, panel gammas, cobweb start) are at the top.
