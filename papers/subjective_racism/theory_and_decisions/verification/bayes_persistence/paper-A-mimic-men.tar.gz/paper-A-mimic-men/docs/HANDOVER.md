# HANDOVER — *Stereotype Rigidity in Social Inferences: A "Mimic Men" Dilemma*
*(state as of 2026-06-21; target: Theory and Decision — "Foundations of Utility and Risk" collection)*

> **EXPECT MANUAL EDITS — RECONCILE BEFORE ACTING.** Anurag edits the manuscript,
> summaries, and bib by hand between sessions. Everything below is the state *as of this
> handover*, not the live state. Next session: (1) re-read the actual files first;
> (2) line numbers are approximate — locate by content (grep), not by line number;
> (3) recompile (pdflatex → bibtex → pdflatex → pdflatex) to confirm it still builds;
> (4) check whether manual edits already addressed the open items below.

## Current state
- `manuscript.tex` — single canonical source. **43 pp, compiles clean** (4-stage; no errors, no undefined refs/citations).
- `bibliography.bib` — references. Verified against primary texts: `Allport1954`, `BergerLuckmann1966`, `DiMaggio1997`, `Sen1973`, `Naipaul1967`. Seven uncited entries removed.
- `verify_discrimination.py` — author's private check (not shipped). Re-run confirmed **91 PASS / 0 FAIL / 11 ANALYTIC**; still contains welfare checks (CHECK_86–90, ANALYTIC_10/11) for the retired addendum — strip or ignore.
- `verify_topology.lean` — Lean 4 topology (canonical instance F = (1−c̄)²).
- `verify_tau_extension.py` — checks for the τ-Remark (`rem:resolution`): 6 SymPy identities + 13 numeric. **19 PASS / 0 FAIL.**
- `tau_extension_sketch.md` — exploratory derivation behind the τ-Remark (not shipped).
- `summary_1500.md`, `summary_300.md` — summaries.
- `figures/` — three figure PDFs + generator scripts.

## Done this session (2026-06-21)
- **Grammar pass** (10 fixes) + **inertial-belief-layer parametrisation** (economic system = {class, mobility γ}; social system = inertial belief layer {standing c̄_g, salience s_g, rigidity ρ}; closure trap = speed mismatch).
- **Related-Literature convergent clause** (preferences-standard paragraph): the typical-case anchoring is documented as cognitive necessity `\citep{Allport1954}`, typification in everyday interaction `\citep{BergerLuckmann1966}`, schematic organisation of culture `\citep{DiMaggio1997}` — "backdrop, not foundation." Every cite verified against its primary text. **Tajfel–Wilkes** (verified = accentuation, not necessity) and **Schutz–Luckmann** (redundant book) were considered and **dropped** — never entered the bib.
- **Parcel vignette** (`ex:misaddressed`) placed after `ex:jeffrey-bayes` as the soft/hard-marker pair. Snap-decision framing (doorstep call, no document, no recourse) so the latent is uncertified within the encounter; posterior-odds footnote trimmed to one line.
- **Sen identification capstone** after the vignette: the mechanism behind any given decision is not claimed to be identified — which of inference, rigidity, or taste produced it is just what choice does not reveal `\citep{Sen1973}`.
- **Keystone → three beats:** (1) benign default — reading through the typical case is a cognitive necessity, costless in the general run; (2) keystone proper — not a refusal to learn but the absence of anything coherent to learn from; (3) harmful condition — a cost only where the category is a standing coupled to economic position; the rule, not the exception, for stigmatised groups.
- **Welfare addendum RETIRED** — `welfare_analysis_addendum.tex` deleted; all welfare references stripped from this handover. Decided irrelevant; do not reinstate. (See verify-script residue above.)

## Done — latest pass (2026-06-21, cont.)
- **Naipaul `The Mimic Men` now cited** — `Naipaul1967` bib entry added; keystone footnote uses `\citep`. Builds clean.
- **Seven orphaned bib entries removed** — `AdidaLaitinValfort2016`, `AustenSmithFryer2005`, `Barth1969`, `DarityHamiltonStewart2015`, `Fiske2002`, `Mamdani1996`, `Tilly1998` (all cited zero times). `BisinVerdier2001` kept (now cited).
- **Scope coda** after the Sen capstone — fixes the mechanism's scope: inferential primitive in isolation; institutions enter later as aggregation (presupposing the rigidity); history enters only as the value of `c̄_g`; resentment/coalitional threat is out.
- **Mimic-men keystone guard** — tail clause on the predicament sentence: the paper takes the predicament's *inferential structure* alone, holding the power asymmetry in the initial conditions, not generating it.
- **τ-Remark (`rem:resolution`)** after `rem:platform-bayes` — individual resolution (precision τ, decision margin) is **orthogonal** to rigidity ρ (updating margin); the closure trap survives any τ; institutional aggregation = the τ=0 corner; micro-founds `app:passing`. Verified in `verify_tau_extension.py` (19/0).
- **ρ\* confirmed** — verify.py gives 0.3084 ≈ 0.31 (manuscript value stands). Lean canonical F=(1−c̄)² gives 0.25; not a conflict (existence is instance-independent).

## Open items
**Optional refinements (offered, not requested)**
- Vignette discussion paragraphs — career arc; feedback loop / four mechanisms (no answer key, censoring, self-confirmation, no aggregator); hard/soft signals. Currently kept terse at example + capstone.
- Restore the full posterior-odds footnote in the vignette.

**Low priority (carried)**
- Shadow-market sign proof tidy; plain-English Q1 line; optional one-line pointer to the platform remark (`rem:platform-bayes`).

## Framing guards — do not let these drift
- **Positive, not normative.** Harm = measurable economic closure (standing frozen low, dragging economic position). No moral language ("unjust", "unfair", "acceptable", "wrong"). The benign/harmful contrast is drawn on coupling/consequence, never moral weight.
- **Jeffrey vs Bayes.** Jeffrey relocates the unidentified object from the unrecoverable likelihood to the elicitable credence, while staying falsifiable on whether the conditional revises. Domain-relative: Bayes where outcomes are certified (contract channel), Jeffrey where not (contact channel). Motive-free — the cause is not recoverable from choice (Sen).
- **Keystone.** Rigidity is not a refusal to learn but the absence of anything coherent to learn from.
- **Convergent literature is backdrop, not foundation** — the rigidity is derived from the information structure, not assumed.
- **Two contributions:** the closure trap (contact channel) + the platform/aggregation channel. Welfare is out.
- **Class is forecast, not observed** — a forecast drawn from the group's standing cannot revise that standing.
- **Scope partition (three loci + one exclusion).** Institutionality-as-history = the *value* of `c̄_g` (a parameter); the updating rule (Jeffrey rigidity) = the power-free inferential primitive; institution-as-mechanism = the aggregation layer (platform). Resentment / coalitional threat / contest over standing is **out** (a contest, not an inference).
- **Mimic-men metaphor is scoped.** The paper takes the predicament's inferential structure; the power asymmetry (which standing is low, which code is adopted) is held in the initial conditions, not generated. Do not let the title's freight pull the model toward modelling power.
- **τ ⊥ ρ.** Token resolution (τ, decision step) and rigidity (ρ, updating step) are independent margins. The trap is a ρ-phenomenon and survives any τ. "Just treat people as individuals" (raise τ) does not fix the group and can deepen the residual via passing.
- **Normative scope — positive only; do not let this drift.** The model makes exactly one descriptive claim about individual marker investment: it is *individually rational, collectively self-defeating* (manuscript ~ll. 1460–1470). Privately it can lower one's own salience `s_g` (passing — mutable markers only) or certify class into the contracting/Bayes channel (the "wealthy enough to buy the shop" type); it never revises the group standing `c̄_g`, and via adverse selection (`prop:passing`) it can *lower* `c̄_g` for those who remain. "Futile" means futile-**at-the-group-level only** — avoid the bare word in prose, it reads as a verdict on the individual that the model does not make. **NOT normative, must not drift:** any ranking of these responses, any "should", any welfare comparison — the retired welfare addendum was protecting exactly this line. `prop:passing`'s private cost–benefit and the selection on `c_i` is the *most* the model says about "how much": it is positive (who passes), not prescriptive (who ought to). The **salience-reduction / certification / neither** trichotomy — with marker *mutability* and *certifiability* as the deciding variables — is the positive content that adjudicates the "credentialed but visibly-marked" vs "wealthy enough to certify class" contrast, without prescribing anything. Render those as *types* in any prose, not as named real figures.
