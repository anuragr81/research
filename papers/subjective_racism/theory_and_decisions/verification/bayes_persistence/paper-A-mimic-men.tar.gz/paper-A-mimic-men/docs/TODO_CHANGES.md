# Master change list — to reconcile against your version

Workflow: you send your `manuscript.tex`. I check each item below against it,
present the not-yet-applied ones as accept/reject with exact old/new, and apply
what you greenlight. Items you've already dropped in get ticked off silently.

## A. Within-group variance — core mechanics (the big recent thread)
- [ ] **A1.** §3.3 opening grounding paragraph, *before* eq:dynamic — breeder's-equation / Fisher's-fundamental-theorem motivation; "mobility term proportional to within-group variance"; directional (variance scales an *upward* push).
- [ ] **A2.** Main paragraph *after* eq:dynamic — dual role: same $\sigma_g^2$ is the inference penalty (CHECK_06) and the upward mobility term $\gamma\sigma_g^2$ (CHECK_51b); whether the group rises is the contest of that push + $\mu$ against the $\delta\phi$ drag.
- [ ] **A3.** Trap paragraph *after* eq:dynamic — $\sigma_g^2 \to 0$ as $\bar c_g \to 0$, mobility term vanishes (CHECK_52, $G(0)=\mu$), low fixed point is absorbing.
- [ ] **A4.** Fix **line 988** — replace "the mobility term … acts as intergenerational regression to the group mean" with the upward, variance-scaled relabel (regression-to-mean is mean-preserving and contradicts CHECK_51b).
- [ ] **A5.** CONSOLIDATION DECISION — A1 and A2 both gesture at "same $\sigma_g^2$ in both places." Decide which one carries that line so it isn't said twice.

## B. Previews & first description
- [ ] **B1.** Preview B — Model section, after the two-system paragraph (directional: raises social distance / scales $\gamma\sigma_g^2$). (Preview A was dropped — do not re-add.)
- [ ] **B2.** First description of variance (l. ~837) — legibility preview ("low variance = legible group, high = label underdetermines the member"); also removes the "matters in its own right:" colon.

## C. Discussion examples
- [ ] **C1.** Taxi / Loury *implicit* example (after "…confirms the prior", l. ~1311) — one sentence making adverse selection variance-explicit (selective exit lowers variance and mean → more legibly low group).
- [ ] **C2.** Anti-establishment *explicit* example (l. ~1362) — legibility echo + the missing mobility link ($\gamma\sigma_g^2$, since the movement also acts on $\gamma$).
- [ ] **C3.** Anti-establishment conflation fix — repoint the "less reliable signal / reduces discrimination" arm to $s_g$ (a separate lever from $\sigma_g^2$), so variance and salience aren't collapsed.

## D. Citations / support (need bib entries)
- [ ] **D1.** Aigner–Cain (1977) at the bias–variance footnote (l. ~835) — the variance branch of statistical discrimination; note your risk-neutral mechanism differs from their risk-aversion one.
- [ ] **D2.** Fisher's fundamental theorem / breeder's equation reference, anchoring A1 (as analogy, not derivation).

## E. Earlier-session drafts — CONFIRM whether already in your version
(You took these as LaTeX to drop in; flagging so the reconcile pass catches any missed.)
- [ ] **E1.** "This is not a Nash equilibrium analysis" sentence — Model section opening.
- [ ] **E2.** Closure-equilibrium *definition* → formal form ($\bar c_g^* = \mathcal{H}(\bar c_g^*)$ and $\phi^* = s_g F(\bar c_g^*)$).
- [ ] **E3.** "The fixed points of the map are the equilibria…" → no-colon rewrite.
- [ ] **E4.** `prop:class-closure` colon → "in which" clause.
- [ ] **E5.** "applies the same second step" → the eq:jeffrey rewrite.
- [ ] **E6.** "Second, because the rigidity…" → simplified three-sentence version.
- [ ] **E7.** Functional-form assumption split (`ass:preferences` / `ass:beliefs`) + corrected wording.
- [ ] **E8.** $D_k$ defined-before-equation + `ass:functional`→`ass:preferences` ref repoint.

## F. Ongoing (not part of this apply-pass)
- Colon reduction — 82 prose colons in `COLON_AUDIT.md`, your manual pass.

## G. Submission preparation (do AFTER content edits are locked)
- [ ] **G1.** Convert `\documentclass[12pt,a4paper]{article}` → Springer Nature
  `sn-jnl` template (official Dec-2024 package, `sn-article-template/`).
  - Use `\documentclass[sn-basic]{sn-jnl}` (Basic SN style, **author-year** — T&D is author-year).
  - Move title/author/affiliation/abstract/keywords into the `sn-jnl` macros;
    re-point theorem environments to the class; switch bibliography to `sn-basic`.
  - Custom `\titleformat` styling (incl. the subsubsection line) gets dropped —
    the class handles it.
  - Heading depth: keep to three levels (`\section`/`\subsection`/`\subsubsection`);
    no fourth level. Confirmed by both T&D guidelines and the template manual §7.1.
  - Grab the latest template version at submission time in case Springer updates it.
  - (Conversion can be done offline from the uploaded package; no network needed.)

## H. Terminology review (your call, do in one consistent pass)
- [ ] **H1.** Inspect and/or replace "utility" terminology for the realized object
  $U = v - \kappa\,d$. It is a *consequence function, not a decision rule* (the
  paper already says so at the engagement-decision derivation), so "utility"
  fights that framing. Candidates: **payoff function** (safest, least loaded),
  or **match value / surplus** (leans into the matching-theory reading and makes
  the $\Delta^*$ acceptance rule self-explanatory). Avoid "objective function"
  (implies optimisation) and "loss function" (reserved for the analyst's
  expected-squared-loss in the 848 footnote).
  - Scope: ~23 "utility" occurrences in prose, the symbol $U$ (incl.
    `eq:utility` and `eq:exp-utility` as $\E[U\mid m_i]$), and `ass:preferences`
    ("enters expected utility at the same weight $\kappa$").
  - Do it as ONE pass so the same object isn't "payoff" in one paragraph and
    "utility" in another. If switching to match value, carry the matching-theory
    framing through the engagement decision, the bilateral two-sided threshold,
    and the passing section.
- [ ] **H2.** (Related, from the same review) Align decomposition language: it is
  the *expected* squared distance $\E[d\mid m_i]$ that decomposes into bias and
  variance, not "squared distance" (l. 429) and not utility. Footnote at 848 is
  already correct; the body sentence is the one to fix. Optionally add a
  half-sentence noting the decomposition is an analytical step on the aggregate
  expected distance, not a bias-variance tradeoff the agent optimises.
